// Recording state management hook
import { useState, useCallback } from 'react';
import { audioService } from '@/services/audioService';
import { transcribeAudio } from '@/services/transcriptionService';

export interface TranscriptionItem {
  id: string;
  text: string;
  timestamp: Date;
  confidence: number;
}

export function useRecording() {
  const [isRecording, setIsRecording] = useState(false);
  const [isTranscribing, setIsTranscribing] = useState(false);
  const [transcriptions, setTranscriptions] = useState<TranscriptionItem[]>([]);
  const [error, setError] = useState<string | null>(null);

  const startRecording = useCallback(async () => {
    try {
      setError(null);
      await audioService.startRecording();
      setIsRecording(true);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to start recording';
      setError(message);
      setIsRecording(false);
    }
  }, []);

  const stopRecording = useCallback(async () => {
    try {
      setIsRecording(false);
      setIsTranscribing(true);
      setError(null);

      const result = await audioService.stopRecording();
      console.log('Recording result:', result);

      // Transcribe the audio
      const { data, error: transcriptionError } = await transcribeAudio(result.uri);

      if (transcriptionError) {
        setError(transcriptionError);
        setIsTranscribing(false);
        return;
      }

      if (data && data.transcript) {
        const newTranscription: TranscriptionItem = {
          id: Date.now().toString(),
          text: data.transcript,
          timestamp: new Date(),
          confidence: data.confidence,
        };
        
        setTranscriptions(prev => [newTranscription, ...prev]);
      } else {
        setError('No speech detected');
      }

      setIsTranscribing(false);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to process recording';
      setError(message);
      setIsRecording(false);
      setIsTranscribing(false);
    }
  }, []);

  const clearTranscriptions = useCallback(() => {
    setTranscriptions([]);
  }, []);

  const deleteTranscription = useCallback((id: string) => {
    setTranscriptions(prev => prev.filter(item => item.id !== id));
  }, []);

  return {
    isRecording,
    isTranscribing,
    transcriptions,
    error,
    startRecording,
    stopRecording,
    clearTranscriptions,
    deleteTranscription,
  };
}
