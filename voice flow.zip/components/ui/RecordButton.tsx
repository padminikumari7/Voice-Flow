// Animated record button component
import React, { useEffect, useRef } from 'react';
import { View, TouchableOpacity, StyleSheet, Animated, useColorScheme } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors, spacing } from '@/constants/theme';

interface RecordButtonProps {
  isRecording: boolean;
  isTranscribing: boolean;
  onPressIn: () => void;
  onPressOut: () => void;
}

export function RecordButton({ isRecording, isTranscribing, onPressIn, onPressOut }: RecordButtonProps) {
  const colorScheme = useColorScheme();
  const theme = colorScheme === 'dark' ? colors.dark : colors.light;
  
  const scaleAnim = useRef(new Animated.Value(1)).current;
  const pulseAnim = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    if (isRecording) {
      // Pulse animation while recording
      Animated.loop(
        Animated.sequence([
          Animated.timing(pulseAnim, {
            toValue: 1.15,
            duration: 800,
            useNativeDriver: true,
          }),
          Animated.timing(pulseAnim, {
            toValue: 1,
            duration: 800,
            useNativeDriver: true,
          }),
        ])
      ).start();
    } else {
      pulseAnim.setValue(1);
    }
  }, [isRecording, pulseAnim]);

  const handlePressIn = () => {
    Animated.spring(scaleAnim, {
      toValue: 0.9,
      useNativeDriver: true,
    }).start();
    onPressIn();
  };

  const handlePressOut = () => {
    Animated.spring(scaleAnim, {
      toValue: 1,
      useNativeDriver: true,
    }).start();
    onPressOut();
  };

  const disabled = isTranscribing;

  return (
    <View style={styles.container}>
      {isRecording && (
        <Animated.View 
          style={[
            styles.pulseRing,
            {
              backgroundColor: theme.recordingGlow,
              transform: [{ scale: pulseAnim }],
            }
          ]} 
        />
      )}
      <Animated.View style={{ transform: [{ scale: scaleAnim }] }}>
        <TouchableOpacity
          onPressIn={handlePressIn}
          onPressOut={handlePressOut}
          disabled={disabled}
          activeOpacity={1}
          style={[
            styles.button,
            {
              backgroundColor: isRecording ? theme.recording : theme.primary,
              opacity: disabled ? 0.5 : 1,
            }
          ]}
        >
          <Ionicons 
            name={isTranscribing ? "hourglass-outline" : isRecording ? "stop" : "mic"} 
            size={48} 
            color="#ffffff" 
          />
        </TouchableOpacity>
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
  },
  pulseRing: {
    position: 'absolute',
    width: 140,
    height: 140,
    borderRadius: 70,
  },
  button: {
    width: 100,
    height: 100,
    borderRadius: 50,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
