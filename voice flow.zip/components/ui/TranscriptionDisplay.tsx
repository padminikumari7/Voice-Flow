// Transcription display component
import React from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, useColorScheme } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as Clipboard from 'expo-clipboard';
import { colors, spacing, typography, borderRadius, shadows } from '@/constants/theme';
import type { TranscriptionItem } from '@/hooks/useRecording';

interface TranscriptionDisplayProps {
  transcriptions: TranscriptionItem[];
  onDelete: (id: string) => void;
  onClear: () => void;
}

export function TranscriptionDisplay({ transcriptions, onDelete, onClear }: TranscriptionDisplayProps) {
  const colorScheme = useColorScheme();
  const theme = colorScheme === 'dark' ? colors.dark : colors.light;

  const copyToClipboard = async (text: string) => {
    await Clipboard.setStringAsync(text);
  };

  const renderItem = ({ item }: { item: TranscriptionItem }) => (
    <View style={[styles.transcriptionCard, { backgroundColor: theme.surface, borderColor: theme.border }]}>
      <View style={styles.cardHeader}>
        <Text style={[styles.timestamp, { color: theme.textSecondary }]}>
          {item.timestamp.toLocaleTimeString()}
        </Text>
        <View style={styles.actions}>
          <TouchableOpacity 
            onPress={() => copyToClipboard(item.text)}
            style={styles.actionButton}
          >
            <Ionicons name="copy-outline" size={20} color={theme.primary} />
          </TouchableOpacity>
          <TouchableOpacity 
            onPress={() => onDelete(item.id)}
            style={styles.actionButton}
          >
            <Ionicons name="trash-outline" size={20} color={theme.error} />
          </TouchableOpacity>
        </View>
      </View>
      <Text style={[styles.transcriptionText, { color: theme.text }]}>
        {item.text}
      </Text>
      {item.confidence > 0 && (
        <Text style={[styles.confidence, { color: theme.textSecondary }]}>
          Confidence: {Math.round(item.confidence * 100)}%
        </Text>
      )}
    </View>
  );

  if (transcriptions.length === 0) {
    return (
      <View style={styles.emptyContainer}>
        <Ionicons name="mic-outline" size={64} color={theme.textSecondary} />
        <Text style={[styles.emptyText, { color: theme.textSecondary }]}>
          Hold the microphone button to start recording
        </Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={[styles.headerTitle, { color: theme.text }]}>
          Transcriptions
        </Text>
        <TouchableOpacity onPress={onClear}>
          <Text style={[styles.clearButton, { color: theme.error }]}>
            Clear All
          </Text>
        </TouchableOpacity>
      </View>
      <FlatList
        data={transcriptions}
        renderItem={renderItem}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.list}
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
  },
  headerTitle: {
    fontSize: typography.sizes.lg,
    fontWeight: typography.weights.semibold,
  },
  clearButton: {
    fontSize: typography.sizes.sm,
    fontWeight: typography.weights.medium,
  },
  list: {
    padding: spacing.md,
    gap: spacing.md,
  },
  transcriptionCard: {
    borderRadius: borderRadius.md,
    padding: spacing.md,
    borderWidth: 1,
    ...shadows.sm,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.sm,
  },
  timestamp: {
    fontSize: typography.sizes.xs,
  },
  actions: {
    flexDirection: 'row',
    gap: spacing.sm,
  },
  actionButton: {
    padding: spacing.xs,
  },
  transcriptionText: {
    fontSize: typography.sizes.md,
    lineHeight: 24,
    marginBottom: spacing.xs,
  },
  confidence: {
    fontSize: typography.sizes.xs,
    fontStyle: 'italic',
  },
  emptyContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: spacing.xl,
  },
  emptyText: {
    fontSize: typography.sizes.md,
    textAlign: 'center',
    marginTop: spacing.md,
  },
});
