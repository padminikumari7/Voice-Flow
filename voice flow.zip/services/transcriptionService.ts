// Transcription service using Deepgram via Edge Function
import { getSupabaseClient } from '@/template';
import { FunctionsHttpError } from '@supabase/supabase-js';

export interface TranscriptionResult {
  transcript: string;
  confidence: number;
}

export async function transcribeAudio(audioUri: string): Promise<{ data: TranscriptionResult | null; error: string | null }> {
  try {
    const supabase = getSupabaseClient();

    console.log('Calling transcribe-audio function...');
    const { data, error } = await supabase.functions.invoke('transcribe-audio', {
      body: { audioUri },
    });

    if (error) {
      let errorMessage = error.message;
      if (error instanceof FunctionsHttpError) {
        try {
          const statusCode = error.context?.status ?? 500;
          const textContent = await error.context?.text();
          errorMessage = `[Code: ${statusCode}] ${textContent || error.message || 'Unknown error'}`;
        } catch {
          errorMessage = `${error.message || 'Failed to read response'}`;
        }
      }
      console.error('Transcription error:', errorMessage);
      return { data: null, error: errorMessage };
    }

    if (data?.error) {
      return { data: null, error: data.error };
    }

    return { 
      data: {
        transcript: data.transcript || '',
        confidence: data.confidence || 0,
      }, 
      error: null 
    };
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Transcription failed';
    console.error('Transcription service error:', message);
    return { data: null, error: message };
  }
}
