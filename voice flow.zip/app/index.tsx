import React from 'react';
import { View, Text, StyleSheet, useColorScheme, Alert } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { RecordButton, TranscriptionDisplay } from '@/components';
import { useRecording } from '@/hooks/useRecording';
import { colors, spacing, typography } from '@/constants/theme';

export default function HomeScreen() {
  const colorScheme = useColorScheme();
  const theme = colorScheme === 'dark' ? colors.dark : colors.light;
  const insets = useSafeAreaInsets();

  const {
    isRecording,
    isTranscribing,
    transcriptions,
    error,
    startRecording,
    stopRecording,
    clearTranscriptions,
    deleteTranscription,
  } = useRecording();

  React.useEffect(() => {
    if (error) {
      Alert.alert('Error', error);
    }
  }, [error]);

  return (
    <View style={[styles.container, { backgroundColor: theme.background, paddingTop: insets.top }]}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={[styles.title, { color: theme.text }]}>
          Voice to Text
        </Text>
        <Text style={[styles.subtitle, { color: theme.textSecondary }]}>
          {isRecording ? 'Recording...' : isTranscribing ? 'Processing...' : 'Press and hold to record'}
        </Text>
      </View>

      {/* Transcription Display */}
      <View style={styles.transcriptionContainer}>
        <TranscriptionDisplay
          transcriptions={transcriptions}
          onDelete={deleteTranscription}
          onClear={clearTranscriptions}
        />
      </View>

      {/* Record Button */}
      <View style={[styles.recordButtonContainer, { paddingBottom: Math.max(insets.bottom, spacing.lg) }]}>
        <RecordButton
          isRecording={isRecording}
          isTranscribing={isTranscribing}
          onPressIn={startRecording}
          onPressOut={stopRecording}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.lg,
    paddingBottom: spacing.md,
    alignItems: 'center',
  },
  title: {
    fontSize: typography.sizes.xxl,
    fontWeight: typography.weights.bold,
    marginBottom: spacing.xs,
  },
  subtitle: {
    fontSize: typography.sizes.md,
  },
  transcriptionContainer: {
    flex: 1,
  },
  recordButtonContainer: {
    alignItems: 'center',
    paddingTop: spacing.lg,
  },
});
